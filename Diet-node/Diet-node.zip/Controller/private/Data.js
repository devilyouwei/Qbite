const db = require('./DB.js');
/*数据统计应该根据订单*/
class Data{
    // 统计收入，輸入時間範圍
    static async income(begintime=0,endtime=Date.parse(new Date())/1000){
    }
    // 餐桌统计
    // 菜品统计
}
module.exports=Data
